Author: George Lenz

Files: change.cpp


To run this file run g++ change.cpp

** You must have a file named amount.txt.


Description: This program runs a minimal change dynamic programming algorithm on a file named amount.txt, then outputs the data to a file named change.txt.


The data is in the format:

Denominations

Amount
Array of each coin

Minimal Amount of coins
*

for each set of data.
