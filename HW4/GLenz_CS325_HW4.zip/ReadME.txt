Files contained: Act.cpp and sort.hpp
Author: George Lenz
Description: uses a greedy algorithm to find the optimal solution to an Activity selection problem
             by using the activities with the latest start time.
Run: run by using g++ act.cpp


