/*******************************************************************
 * Program Name: act.cpp
 * Author: George Lenz
 * Date: 7/22/2018
 * Description: Uses a greedy algorithm to find the optimal solution for selecting the most activities in a limited amount of time by selecting the last activity to start.
 *********************************************************************/
#include <iostream>
#include <fstream>
#include <stdlib.h>
#include "sort.hpp"
#include "vector"

using namespace std;


//outputs activities in an optimal solution and the activities
void lastToFirst(Activity* activities, int size)
{
    vector<Activity> solution;
    //sort the array of activities
    mergeSort(activities, 0, size-1);
    //add latest start time to solution
    solution.push_back(activities[size-1]);
    //loop through actvities from last start to first
    for(int i = size-2; i >= 0; i--)
    {
        //add item if it doesn't overlap
        if (activities[i].endTime <= solution[solution.size() - 1].startTime)
        {
            solution.push_back(activities[i]);
   
        }
    }
    
    //output number of activities and the activity
    cout << "Number of activities selected = " <<solution.size() << endl; 
    cout << "Activities: ";   
    for(int i = solution.size() - 1; i >=0; i--)
    {
        cout << solution[i].number << " ";
    }
    cout << endl;
    
}

int main()
{
    //open file
    ifstream iFile;
    iFile.open("act.txt");
    int x; //used for file input
    int n = 1; // used for to keep track of set number

    //loop until end of file
    while(iFile >> x)
    {
        //create array of activities
        Activity* activityList = new Activity[x];
     
        //initialize each activity from file
        for(int i=0; i<x; i++)
        {
     
            iFile >> activityList[i].number;
            iFile >> activityList[i].startTime;
            iFile >> activityList[i].endTime;
       
        }
      
        //output set number
        cout << "Set " << n << endl;

        //output number of activities in solution and solution
        lastToFirst(activityList, x);
        
        cout << endl; 

        //clear the array 
        free(activityList);
   
        //increment set number
        n++;
     } 
              
    return 0;
}
