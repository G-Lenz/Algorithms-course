/**************************************************************
 * Program: sort.hpp
 * Author: George Lenz
 * Date 7/22/2018
 * Description: Struct and sort function for sorting activities
 ****************************************************************/

#ifndef SORT_HPP
#define SORT_HPP

#include <iostream>
using namespace std;

//Activity struct
struct Activity
{
    int number;
    int startTime;
    int endTime;

    //assignement operator for activities
    Activity operator =(const Activity* a)
    {
        number = a->number;
        startTime = a->startTime;
        endTime = a->endTime;
        return *this;
    }
};

//Merge sort for Activities by latest start time
void merge(Activity* array, int left, int middle, int right)
{
    //get size of left and right array
    int n1 = middle - left + 1;
    int n2 = right - middle;

    //initialize arrays
    Activity* leftArray = new Activity[n1];
    Activity* rightArray = new Activity[n2];

    //fill left array with left half of original array
    for(int i = 0; i < n1; i++)
    {
        leftArray[i] = array[left + i];
    }
   
    //fill rightArray with right half of original array
    for(int j=0; j<n2; j++)
    {
        rightArray[j] = array[middle + 1 + j];
    }
    
    int i = 0;
    int j = 0;
    int k = left;

    //merge the two arrays back together in sorted order
   while(i < n1 && j < n2)
    {
        if(leftArray[i].startTime <= rightArray[j].startTime)
        {
            array[k] = leftArray[i];
            i++;
        }
        
        else
        {
            array[k] = rightArray[j];
            j++;
        }
        k++;
    }

    while(i < n1)
    {
        array[k] = leftArray[i];
        i++;
        k++;
    }

    while(j<n2)
    {
        array[k] = rightArray[j];
        j++;
        k++;
    }
    
}
    
void mergeSort(Activity* array, int left, int right)
{
    if(left < right)
    {
        int middle = (left + right) / 2;
        mergeSort(array, left, middle);
        mergeSort(array, middle + 1, right);
        merge(array, left, middle, right);
    }
}

#endif
