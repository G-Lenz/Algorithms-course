George Lenz
CS-325 HW2 Question 5.

This code can be run with g++ stoogesort.cpp.
It takes a file named data.txt and sorts the data to an output file named stooge.out


