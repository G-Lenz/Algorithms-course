/*************************************************************
 * Program Name: bin.cpp
 * Author: George Lenz
 * Date 8/16/2018
 * Description: Contains two bin packing algorithms, one that puts them in from an unsorted list and the second from a sorted one.
 *************************************************************/
#include <iostream>
#include <vector>
#include <fstream>
#include "mergeSort.hpp"
using namespace std;

int firstFit(int* array, int arraySize, int binSize)
{
    vector<int> bins; 
    bins.push_back(0);
    
    for(int i = 0; i < arraySize; i++)
    {   
        int j = 0;
        while(j <= bins.size())
        {
            if(bins[j] + array[i] <= 10)
            {
                bins[j] = bins[j] + array[i];
                break;
            }
            else
            {
                j++;
                if(j >= bins.size())
                {
                    bins.push_back(array[i]);
                    break;
                }
            }
        }
    }
    return bins.size();
}

int firstFitDecreasing(int* array, int arraySize, int binSize)
{
    vector<int> bins; 
    bins.push_back(0);
    int j = 0;
    mergeSort(array, 0, arraySize - 1);
    for(int i = 0; i < arraySize; i++)
    {
        int j = 0;
        while(j <= bins.size())
        {
            if(bins[j] + array[i] <= 10)
            {
                bins[j] = bins[j] + array[i];
                break;
            }
            else
            {
                j++;
                if(j >= bins.size())
                {
                    bins.push_back(array[i]);
                    break;
                }
            }
         }
    }
    return bins.size();
}

int main()
{
    ifstream iFile;
    iFile.open("bin.txt");

    int testCase;
    int binSize;
    int arraySize;
    int item;
    int binAmt;
    iFile >> testCase;
    for(int i = 0; i < testCase; i++)
    {
        
        iFile >> binSize;
        iFile >> arraySize;
        int array[arraySize];
        
        for (int j = 0; j < arraySize; j++)
        {
            iFile >> item;
            array[j] = item;
        }
        cout << "Test Case " << i + 1 << " First Fit: ";
        binAmt = firstFit(array, arraySize, binSize);
        cout << binAmt;
        binAmt = firstFitDecreasing(array, arraySize, binSize);
        cout << " - First Fit Decreasing: " << binAmt << endl;

     }
         

 

    
    return 0;
}     
